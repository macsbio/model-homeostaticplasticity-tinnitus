%%%% Runs AC_Model to calculate and plot channel FTCs, and calculate their
%%%% TWs. The model must be converted to a function that accepts a carrier
%%%% frequency as input, and forms stimulus s=sin(2*pi*car_freq*t).
% Author: Kabir Arora
% Extensions: additionally constructing FTCs for HL and HSP models and
% adding possibility of denser sampling close to BF and coarser sampling at
% non-preferred frequencies

%Author: Hannah Schultheiss

load('F.mat')
F=F(2:end-1);

% Channels to inspect
channels = [1:98]; % 1:98 for full

% Data points on tuning curve
%fine determines sampling close to BF, coarse at non-preferred frequencies
n_runs_fine = 70; %300 provides precision of TW upto 0.002 oct
n_runs_coarse = 70;

tw_Healthy = zeros(98,1); tw_HL= tw_Healthy; tw_HSP= tw_Healthy;
bf_Healthy = tw_Healthy; bf_HL= tw_Healthy; bf_HSP=tw_Healthy;
%%

freq_range_fine = zeros(numel(channels),n_runs_fine); freq_range_left_fine = zeros(numel(channels), n_runs_fine/2);
freq_range_right_fine = freq_range_left_fine; responsesAxis_fine = freq_range_fine;
freq_range_coarse = zeros(numel(channels),n_runs_coarse); freq_range_left_coarse = zeros(numel(channels), n_runs_coarse/2); 
freq_range_right_coarse = freq_range_left_coarse; responsesAxis_coarse = freq_range_coarse;

%fine-tuned FTC
for j = 1:numel(channels)

    car_freq = F(channels(j)); % Current center frequency (CF), Hz

    % Prepare range of frequencies around CF to use as input
    left_end_fine = (2*(car_freq))/(sqrt(2)+1);
    right_end_fine = (sqrt(2))*(2*(car_freq+10))/(sqrt(2)+1);
    freq_range_fine(j,:)= MakeErbCFs(left_end_fine, right_end_fine, n_runs_fine);
    freq_range_left_fine(j,:) = freq_range_fine(j,1:n_runs_fine/2);
    freq_range_right_fine(j,:)= freq_range_fine(j,(n_runs_fine/2+1):end);
    responsesAxis_fine(channels(j),:) = freq_range_fine(j,:);
end

%coarse FTC
for j = 1:numel(channels)

    car_freq = F(channels(j)); % Current center frequency (CF), Hz

    % Prepare range of frequencies around CF to use as input
    left_end_coarse = 2^(-0.6)*car_freq;
    right_end_coarse = 2^(0.6)*car_freq;
    freq_range_coarse(j,:)= MakeErbCFs(left_end_coarse, right_end_coarse, n_runs_coarse);
    freq_range_left_coarse(j,:) = freq_range_coarse(j,1:n_runs_coarse/2);
    freq_range_right_coarse(j,:)= freq_range_coarse(j,(n_runs_coarse/2+1):end);
    responsesAxis_coarse(channels(j),:) = freq_range_coarse(j,:);
end

%concatenate fine and coarse FTCs
keep_low = responsesAxis_coarse < responsesAxis_fine(:,1);
keep_high = responsesAxis_coarse > responsesAxis_fine(:,end);

freq_range_left = [responsesAxis_coarse(:,keep_low(1,:)), freq_range_left_fine];
freq_range_right = [freq_range_right_fine, responsesAxis_coarse(:,keep_high(1,:))];
responsesAxis = [freq_range_left, freq_range_right];
%%
%Healthy tuning curve
for j = 1:numel(channels)

    car_freq = F(channels(j)); % Current center frequency (CF), Hz

    a1OutputEx_Temp=AC_ModelHealthy_FTC(car_freq);
    activityDistributionE= mean(a1OutputEx_Temp');
    max_fr= activityDistributionE(channels(j));

    % Record unit activity around CF
    for i = numel(freq_range_left(j,:)):-1:1
        [a1OutputEx_Temp] = AC_ModelHealthy_FTC(freq_range_left(j,i));
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_Healthy(channels(j),i) = activityDistributionE(channels(j));
    end

    for i = 1: numel(freq_range_right(j,:))
        [a1OutputEx_Temp] = AC_ModelHealthy_FTC(freq_range_right(j,i));
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_Healthy(channels(j),(i+size(freq_range_left,2))) = activityDistributionE(channels(j));
    end
    disp(strcat('Healthy - Done with number: ',num2str(channels(j))))

end

%Calculate Tuning Widths and find best frequency - Healthy

for i = 1:98
    % Find half-peak index+value
    clear max_v; clear max_i
    [max_v, max_i] = max(responses_Healthy(i,:));
    half_peak = max_v/2;

    % Find indices of half-peak value
    left_set = responses_Healthy(i,1:max_i);
    right_set = responses_Healthy(i,max_i+1:end);
    [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
    [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));

    % Calculate TW in octaves
    tw_Healthy(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));

    % Find BF of the channel
    bf_Healthy(i) = responsesAxis(i,max_i);

end

save("fullFTC_healthy_extended", "responses_Healthy")

pHL_ranges = [0.4 0.6 0.8]; %percentage hearing loss
HL_ranges= [10, 20, 40]; % number of channels affected by hearing loss

for ii = 1: length(pHL_ranges)
    for jj = 1:length(HL_ranges)
        pHL = pHL_ranges(ii);
        range = HL_ranges(jj);

        disp(strcat('Now at Range: ', num2str(range), ' and pHL: ', num2str(pHL)))
        %HSP without update P 
        %load synaptic weights for construction of HSP FTCs
        
        load('synWeights_HSP_noUpdateP.mat');
        updateP=ones(98,1);

        EEgain= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_EEgain'));
        IEgain= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_IEgain'));

        %HL tuning curve

        %%Obtain channel responses
        for j = 1:numel(channels)

            car_freq = F(channels(j)); % Current center frequency (CF), Hz

            a1OutputEx_Temp=AC_ModelHL_FTC(car_freq,pHL, range);
            activityDistributionE= mean(a1OutputEx_Temp');
            max_fr= activityDistributionE(channels(j));

            % Record unit activity around CF HL
            for i = numel(freq_range_left(j,:)):-1:1
                [a1OutputEx_Temp] = AC_ModelHL_FTC(freq_range_left(j,i),pHL, range);
                close all
                activityDistributionE = mean(a1OutputEx_Temp');
                responses_HL(channels(j),i) = activityDistributionE(channels(j));

            end

            for i = 1: numel(freq_range_right(j,:))
                [a1OutputEx_Temp] = AC_ModelHL_FTC(freq_range_right(j,i),pHL, range);
                close all
                activityDistributionE = mean(a1OutputEx_Temp');
                responses_HL(channels(j),(i+size(freq_range_left,2))) = activityDistributionE(channels(j));

            end
            disp(strcat('HL - Done with number: ',num2str(channels(j))))
        end

        %%Calculate Tuning Widths HL

        for i = 1:98
            % Find half-peak index+value
            clear max_v; clear max_i
            [max_v, max_i] = max(responses_HL(i,:));
            half_peak = max_v/2;

            % Find indices of half-peak value
            left_set = responses_HL(i,1:max_i);
            right_set = responses_HL(i,max_i+1:end);
            [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
            [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));

            % Calculate TW in octaves
            tw_HL(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));

            % Find BF of the channel
            bf_HL(i) = responsesAxis(i,max_i);
        end

        save(strcat("fullFTC_HL_extended_range",num2str(range), "_hl", num2str(pHL*100)), "responses_HL")

        HSP tuning curve

        %Obtain channel responses
        for j = 1:numel(channels)

            car_freq = F(channels(j)); % Current center frequency (CF), Hz

            a1OutputEx_Temp=AC_ModelHSP_FTC(car_freq,pHL, range, EEgain, IEgain, j, updateP);
            activityDistributionE= mean(a1OutputEx_Temp');
            max_fr= activityDistributionE(channels(j));

            % Record unit activity around CF HL
            for i = numel(freq_range_left(j,:)):-1:1
                [a1OutputEx_Temp] = AC_ModelHSP_FTC(freq_range_left(j,i),pHL, range, EEgain, IEgain, j, updateP);
                close all
                activityDistributionE = mean(a1OutputEx_Temp');
                responses_HSP(channels(j),i) = activityDistributionE(channels(j));
            end

            for i = 1: numel(freq_range_right(j,:))
                [a1OutputEx_Temp] = AC_ModelHSP_FTC(freq_range_right(j,i),pHL, range, EEgain, IEgain, j, updateP);
                close all
                activityDistributionE = mean(a1OutputEx_Temp');
                responses_HSP(channels(j),(i+size(freq_range_left,2))) = activityDistributionE(channels(j));
            end
            disp(strcat('HSP no update P - Done with number: ',num2str(channels(j))))
        end

        %Calculate Tuning Widths HSP

        for i = 1:98
            % Find half-peak index+value
            clear max_v; clear max_i
            [max_v, max_i] = max(responses_HSP(i,:));
            half_peak = max_v/2;

            % Find indices of half-peak value
            left_set = responses_HSP(i,1:max_i);
            right_set = responses_HSP(i,max_i+1:end);
            [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
            [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));

            % Calculate TW in octaves
            tw_HSP(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));

            % Find BF of the channel
            bf_HSP(i) = responsesAxis(i,max_i);
        end
        
       save(strcat("fullFTC_HSP_EEIE_extended_range",num2str(range), "_hl", num2str(pHL*100)), "responses_HSP")

        % HSP with update P

        load('synWeights_HSP_updateP.mat');
        
        updateP= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_updateP'));
        EEgain= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_EEgain'));
        IEgain= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_IEgain'));

        for j = 1:numel(channels)

            car_freq = F(channels(j)); % Current center frequency (CF), Hz

            a1OutputEx_Temp=AC_ModelHSP_FTC(car_freq,pHL, range, EEgain, IEgain, j, updateP);
            activityDistributionE= mean(a1OutputEx_Temp');
            max_fr= activityDistributionE(channels(j));

            % Record unit activity around CF HL
            for i = numel(freq_range_left(j,:)):-1:1
                [a1OutputEx_Temp] = AC_ModelHSP_FTC(freq_range_left(j,i),pHL, range, EEgain, IEgain, j, updateP);
                close all
                activityDistributionE = mean(a1OutputEx_Temp');
                responses_HSP(channels(j),i) = activityDistributionE(channels(j));
            end

            for i = 1: numel(freq_range_right(j,:))
                [a1OutputEx_Temp] = AC_ModelHSP_FTC(freq_range_right(j,i),pHL, range, EEgain, IEgain, j, updateP);
                close all
                activityDistributionE = mean(a1OutputEx_Temp');
                responses_HSP(channels(j),(i+size(freq_range_left,2))) = activityDistributionE(channels(j));
            end
            disp(strcat('HSP updateP- Done with number: ',num2str(channels(j))))
        end

        %Calculate Tuning Widths HSP

        for i = 1:98
            % Find half-peak index+value
            clear max_v; clear max_i
            [max_v, max_i] = max(responses_HSP(i,:));
            half_peak = max_v/2;

            % Find indices of half-peak value
            left_set = responses_HSP(i,1:max_i);
            right_set = responses_HSP(i,max_i+1:end);
            [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
            [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));

            % Calculate TW in octaves
            tw_HSP(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));

            % Find BF of the channel
            bf_HSP(i) = responsesAxis(i,max_i);
        end
        
        save(strcat("fullFTC_HSP_EEIEP_extended_range",num2str(range), "_hl", num2str(pHL*100)), "responses_HSP")
    end
end
% Plot FTCs

% figure(1);
% for i = 1: length(channels)
%     plot(responsesAxis(channels(i),:),responses_Healthy(channels(i),:))
%     hold on
%     plot(responsesAxis(channels(i),:),responses_HL(channels(i),:))
%     plot(responsesAxis(channels(i),:),responses_HSP(channels(i),:))
% end
% 
% title('Frequency Tuning Curves '); xlabel('Frequency (Hz)'); ylabel('A1 Excitatory Activity');
% legend ('Healthy', 'Hearing Loss', 'HSP');

function y=HzToErbRate(x)
% Convert Hz to ERB rate
%
%   y=HzToErbRate(x)
%
%   y = HzToErbRate(x) converts the frequency X (in Hz) to
%   the eqivalent ERB number.
%
%   See also ERBRATETOHZ, MAKEERBCFS.

% !---
% ==========================================================
% Last changed:     $Date: 2012-10-28 13:02:39 +0000 (Sun, 28 Oct 2012) $
% Last committed:   $Revision: 210 $
% Last changed by:  $Author: ch0022 $
% ==========================================================
% !---

y=(21.4*log10(4.37e-3*x+1));

% [EOF]
end
function cfs = MakeErbCFs(mincf,maxcf,numchans)
% Make a series of center frequencies equally spaced in ERB-rate.
%
%   cfs = MakeErbCFs(mincf,maxcf,numchans)
%
%   This function makes a vector of center frequenies
%   equally spaced on the ERB-rate scale.
%
%   cfs = MakeErbCFs(mincf,maxcf,numchans) creates numchans
%   centre frequencies between mincf and maxcf.
%
%   Adapted from code written by: Guy Brown, University of
%   Sheffield and Martin Cooke.
%
%   See also ERBRATETOHZ, HZTOERBRATE.

% !---
% ==========================================================
% Last changed:     $Date: 2012-10-28 13:02:39 +0000 (Sun, 28 Oct 2012) $
% Last committed:   $Revision: 210 $
% Last changed by:  $Author: ch0022 $
% ==========================================================
% !---

cfs = ErbRateToHz(linspace(HzToErbRate(mincf),HzToErbRate(maxcf),numchans));

% [EOF]
end
function y=ErbRateToHz(x)
% Convert ERB rate to Hz.
%
%   y = ErbRateToHz(x)
%
%   y = ErbRateToHz(x) converts the ERB number x to the
%   eqivalent frequency y (in Hz).
%
% See also HZTOERBRATE.

% !---
% ==========================================================
% Last changed:     $Date: 2012-10-28 13:02:39 +0000 (Sun, 28 Oct 2012) $
% Last committed:   $Revision: 210 $
% Last changed by:  $Author: ch0022 $
% ==========================================================
% !---

y=(10.^(x/21.4)-1)/4.37e-3;

% [EOF]
end