%%%% Runs AC_Model to calculate and plot channel FTCs, and calculate their
%%%% TWs. The model must be converted to a function that accepts a carrier
%%%% frequency as input, and forms stimulus s=sin(2*pi*car_freq*t).
% Author: Kabir Arora
% Extensions: additionally constructing FTCs for HL and HSP models

%Author: Hannah Schultheiss

% Load center frequencies of units to use as starting point
load('F.mat')
F=F(2:end-1);

pHL= 0.4; %percentage hearing loss
range= 10; % number of channels affected by hearing loss

%load synaptic weights for construction of HSP FTCs
%for FTC construction of HSP models without updated input P, uncomment the
%next two lines
load('synWeights_HSP_noUpdateP.mat');
updateP=ones(98,1);

%for FTC construction of HSP models with updated input P, uncomment the
%next two lines
%load('synWeights_HSP_updateP.mat');
%updateP= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_updateP'));

EEgain= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_EEgain'));
IEgain= eval(strcat('synweights_range', num2str(range), '_hl', num2str(pHL*100), '_IEgain'));

% Channels to inspect
channels = [1:98]; % 1:98 for full

% Data points on tuning curve
n_runs = 70; %300 provides precision of TW upto 0.002 oct

responses_Healthy = zeros(98,n_runs); freq_range=responses_Healthy; responsesAxis= responses_Healthy;responses_HL= responses_Healthy; responses_HSP=responses_Healthy;
freq_range_left= zeros(98, n_runs/2); freq_range_right= freq_range_left;


tw_Healthy = zeros(98,1); tw_HL= tw_Healthy; tw_HSP= tw_Healthy;
bf_Healthy = tw_Healthy; bf_HL= tw_Healthy; bf_HSP=tw_Healthy;

for j = 1:numel(channels)
    
    car_freq = F(channels(j)); % Current center frequency (CF), Hz
    
    % Prepare range of frequencies around CF to use as input
    left_end = (2*(car_freq))/(sqrt(2)+1);
    right_end = (sqrt(2))*(2*(car_freq+10))/(sqrt(2)+1);
    freq_range(j,:)= MakeErbCFs(left_end, right_end, n_runs);
    freq_range_left(j,:) = freq_range(j,1:n_runs/2);
    freq_range_right(j,:)= freq_range(j,(n_runs/2+1):end);
    responsesAxis(channels(j),:) = freq_range(j,:);
end

%Healthy tuning curve
for j = 1:numel(channels)
    
    car_freq = F(channels(j)); % Current center frequency (CF), Hz
    
    a1OutputEx_Temp=AC_ModelHealthy_FTC(car_freq);
    activityDistributionE= mean(a1OutputEx_Temp');
    max_fr= activityDistributionE(channels(j));
    
    % Record unit activity around CF
    for i = numel(freq_range_left(j,:)):-1:1
        [a1OutputEx_Temp] = AC_ModelHealthy_FTC(freq_range_left(j,i));
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_Healthy(channels(j),i) = activityDistributionE(channels(j));
        
        %stop when the half max point is reached to reduce computational
        %time
        if responses_Healthy(channels(j),i) < max_fr/2
            break
        end
    end
    
    for i = 1: numel(freq_range_right(j,:))
        [a1OutputEx_Temp] = AC_ModelHealthy_FTC(freq_range_right(j,i));
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_Healthy(channels(j),(i+n_runs/2)) = activityDistributionE(channels(j));
        if responses_Healthy(channels(j),(i+n_runs/2)) < max_fr/2
            break
        end
    end
    disp(strcat('Healthy - Done with number: ',num2str(channels(j))))
    
end

%Calculate Tuning Widths and find best frequency - Healthy

for i = 1:98
    % Find half-peak index+value
    clear max_v; clear max_i
    [max_v, max_i] = max(responses_Healthy(i,:));
    half_peak = max_v/2;
    
    % Find indices of half-peak value
    left_set = responses_Healthy(i,1:max_i);
    right_set = responses_Healthy(i,max_i+1:end);
    [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
    [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));
    
    % Calculate TW in octaves
    tw_Healthy(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));
    
    % Find BF of the channel
    bf_Healthy(i) = responsesAxis(i,max_i);
    
end

%HL tuning curve

%%Obtain channel responses
for j = 1:numel(channels)
    
    car_freq = F(channels(j)); % Current center frequency (CF), Hz
    
    a1OutputEx_Temp=AC_ModelHL_FTC(car_freq,pHL, range);
    activityDistributionE= mean(a1OutputEx_Temp');
    max_fr= activityDistributionE(channels(j));
    
    % Record unit activity around CF HL
    for i = numel(freq_range_left(j,:)):-1:1
        [a1OutputEx_Temp] = AC_ModelHL_FTC(freq_range_left(j,i),pHL, range);
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_HL(channels(j),i) = activityDistributionE(channels(j));
        if responses_HL(channels(j),i) < max_fr/2
            break
        end
    end
    
    for i = 1: numel(freq_range_right(j,:))
        [a1OutputEx_Temp] = AC_ModelHL_FTC(freq_range_right(j,i),pHL, range);
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_HL(channels(j),(i+n_runs/2)) = activityDistributionE(channels(j));
        if responses_HL(channels(j),(i+n_runs/2)) < max_fr/2
            break
        end
    end
    disp(strcat('HL - Done with number: ',num2str(channels(j))))
end

%%Calculate Tuning Widths HL

for i = 1:98
    % Find half-peak index+value
    clear max_v; clear max_i
    [max_v, max_i] = max(responses_HL(i,:));
    half_peak = max_v/2;
    
    % Find indices of half-peak value
    left_set = responses_HL(i,1:max_i);
    right_set = responses_HL(i,max_i+1:end);
    [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
    [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));
    
    % Calculate TW in octaves
    tw_HL(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));
    
    % Find BF of the channel
    bf_HL(i) = responsesAxis(i,max_i);
end


%HSP tuning curve

%%Obtain channel responses
for j = 1:numel(channels)
    
    car_freq = F(channels(j)); % Current center frequency (CF), Hz
    
    a1OutputEx_Temp=AC_ModelHSP_FTC(car_freq,pHL, range, EEgain, IEgain, j, updateP);
    activityDistributionE= mean(a1OutputEx_Temp');
    max_fr= activityDistributionE(channels(j));
    
    % Record unit activity around CF HL
    for i = numel(freq_range_left(j,:)):-1:1
        [a1OutputEx_Temp] = AC_ModelHSP_FTC(freq_range_left(j,i),pHL, range, EEgain, IEgain, j, updateP);
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_HSP(channels(j),i) = activityDistributionE(channels(j));
        if responses_HSP(channels(j),i) < max_fr/2
            break
        end
    end
    
    for i = 1: numel(freq_range_right(j,:))
        [a1OutputEx_Temp] = AC_ModelHSP_FTC(freq_range_right(j,i),pHL, range, EEgain, IEgain, j, updateP);
        close all
        activityDistributionE = mean(a1OutputEx_Temp');
        responses_HSP(channels(j),(i+n_runs/2)) = activityDistributionE(channels(j));
        if responses_HSP(channels(j),(i+n_runs/2)) < max_fr/2
            break
        end
    end
    disp(strcat('HSP - Done with number: ',num2str(channels(j))))
end

%Calculate Tuning Widths HSP

for i = 1:98
    % Find half-peak index+value
    clear max_v; clear max_i
    [max_v, max_i] = max(responses_HSP(i,:,m));
    half_peak = max_v/2;
    
    % Find indices of half-peak value
    left_set = responses_HSP(i,1:max_i);
    right_set = responses_HSP(i,max_i+1:end);
    [half_left_val, half_left_i] = min(abs(half_peak*ones(size(left_set))-left_set));
    [half_right_val, half_right_i] = min(abs(half_peak*ones(size(right_set))-right_set));
    
    % Calculate TW in octaves
    tw_HSP(i) = log2(responsesAxis(i,half_right_i+numel(left_set))/responsesAxis(i,half_left_i));
    
    % Find BF of the channel
    bf_HSP(i) = responsesAxis(i,max_i);
end

% Plot FTCs

figure(1);
for i = 1: length(channels)
    plot(responsesAxis(channels(i),:),responses_Healthy(channels(i),:))
    hold on
    plot(responsesAxis(channels(i),:),responses_HL(channels(i),:))
    plot(responsesAxis(channels(i),:),responses_HSP(channels(i),:))
end

title('Frequency Tuning Curves '); xlabel('Frequency (Hz)'); ylabel('A1 Excitatory Activity');
legend ('Healthy', 'Hearing Loss', 'HSP');

function y=HzToErbRate(x)
% Convert Hz to ERB rate
%
%   y=HzToErbRate(x)
%
%   y = HzToErbRate(x) converts the frequency X (in Hz) to
%   the eqivalent ERB number.
%
%   See also ERBRATETOHZ, MAKEERBCFS.

% !---
% ==========================================================
% Last changed:     $Date: 2012-10-28 13:02:39 +0000 (Sun, 28 Oct 2012) $
% Last committed:   $Revision: 210 $
% Last changed by:  $Author: ch0022 $
% ==========================================================
% !---

y=(21.4*log10(4.37e-3*x+1));

% [EOF]
end
function cfs = MakeErbCFs(mincf,maxcf,numchans)
% Make a series of center frequencies equally spaced in ERB-rate.
%
%   cfs = MakeErbCFs(mincf,maxcf,numchans)
%
%   This function makes a vector of center frequenies
%   equally spaced on the ERB-rate scale.
%
%   cfs = MakeErbCFs(mincf,maxcf,numchans) creates numchans
%   centre frequencies between mincf and maxcf.
%
%   Adapted from code written by: Guy Brown, University of
%   Sheffield and Martin Cooke.
%
%   See also ERBRATETOHZ, HZTOERBRATE.

% !---
% ==========================================================
% Last changed:     $Date: 2012-10-28 13:02:39 +0000 (Sun, 28 Oct 2012) $
% Last committed:   $Revision: 210 $
% Last changed by:  $Author: ch0022 $
% ==========================================================
% !---

cfs = ErbRateToHz(linspace(HzToErbRate(mincf),HzToErbRate(maxcf),numchans));

% [EOF]
end
function y=ErbRateToHz(x)
% Convert ERB rate to Hz.
%
%   y = ErbRateToHz(x)
%
%   y = ErbRateToHz(x) converts the ERB number x to the
%   eqivalent frequency y (in Hz).
%
% See also HZTOERBRATE.

% !---
% ==========================================================
% Last changed:     $Date: 2012-10-28 13:02:39 +0000 (Sun, 28 Oct 2012) $
% Last committed:   $Revision: 210 $
% Last changed by:  $Author: ch0022 $
% ==========================================================
% !---

y=(10.^(x/21.4)-1)/4.37e-3;

% [EOF]
end